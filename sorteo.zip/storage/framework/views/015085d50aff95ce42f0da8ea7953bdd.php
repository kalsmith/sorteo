<p><?php echo e($mensaje); ?></p>
<?php /**PATH C:\Laravel\sorteo\resources\views/emails/ticket.blade.php ENDPATH**/ ?>